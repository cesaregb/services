-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema msgdb
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `msgdb` ;

-- -----------------------------------------------------
-- Schema msgdb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `msgdb` DEFAULT CHARACTER SET utf8 ;
USE `msgdb` ;

-- -----------------------------------------------------
-- Table `msgdb`.`User`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `msgdb`.`User` ;

CREATE TABLE IF NOT EXISTS `msgdb`.`User` (
  `idUser` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NULL,
  `name` VARCHAR(200) NULL,
  `email` VARCHAR(100) NULL,
  `deleted` INT NULL DEFAULT 0,
  PRIMARY KEY (`idUser`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `msgdb`.`Twit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `msgdb`.`Twit` ;

CREATE TABLE IF NOT EXISTS `msgdb`.`Twit` (
  `idTwit` INT NOT NULL AUTO_INCREMENT,
  `text` VARCHAR(140) NULL,
  `created` DATETIME NULL,
  `idUser` INT NOT NULL,
  PRIMARY KEY (`idTwit`),
  INDEX `fk_Twitts_Users_idx` (`idUser` ASC),
  CONSTRAINT `fk_Twitts_Users`
    FOREIGN KEY (`idUser`)
    REFERENCES `msgdb`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `msgdb`.`Follow`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `msgdb`.`Follow` ;

CREATE TABLE IF NOT EXISTS `msgdb`.`Follow` (
  `idFollow` INT NOT NULL AUTO_INCREMENT,
  `idUser` INT NOT NULL,
  `idFollower` INT NOT NULL,
  PRIMARY KEY (`idFollow`),
  INDEX `fk_Follows_Users1_idx` (`idUser` ASC),
  CONSTRAINT `fk_Follows_Users1`
    FOREIGN KEY (`idUser`)
    REFERENCES `msgdb`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `msgdb`.`User`
-- -----------------------------------------------------
START TRANSACTION;
USE `msgdb`;
INSERT INTO `msgdb`.`User` (`idUser`, `username`, `name`, `email`, `deleted`) VALUES (1, 'username', 'name', 'email@domain.com', 0);
INSERT INTO `msgdb`.`User` (`idUser`, `username`, `name`, `email`, `deleted`) VALUES (2, 'username2', 'name2', 'email@aaaa.com', 0);
INSERT INTO `msgdb`.`User` (`idUser`, `username`, `name`, `email`, `deleted`) VALUES (3, 'username3', 'name3', 'email3@bbbb.com', 0);

COMMIT;


-- -----------------------------------------------------
-- Data for table `msgdb`.`Twit`
-- -----------------------------------------------------
START TRANSACTION;
USE `msgdb`;
INSERT INTO `msgdb`.`Twit` (`idTwit`, `text`, `created`, `idUser`) VALUES (1, 'abc', '2017-01-12 18:15:50', 1);
INSERT INTO `msgdb`.`Twit` (`idTwit`, `text`, `created`, `idUser`) VALUES (2, '123', '2017-01-12 18:15:50', 1);
INSERT INTO `msgdb`.`Twit` (`idTwit`, `text`, `created`, `idUser`) VALUES (3, 'zxy', '2017-01-12 18:15:50', 2);

COMMIT;


-- -----------------------------------------------------
-- Data for table `msgdb`.`Follow`
-- -----------------------------------------------------
START TRANSACTION;
USE `msgdb`;
INSERT INTO `msgdb`.`Follow` (`idFollow`, `idUser`, `idFollower`) VALUES (1, 1, 2);
INSERT INTO `msgdb`.`Follow` (`idFollow`, `idUser`, `idFollower`) VALUES (2, 2, 1);
INSERT INTO `msgdb`.`Follow` (`idFollow`, `idUser`, `idFollower`) VALUES (3, 1, 3);

COMMIT;

USE `msgdb`;

DELIMITER $$

USE `msgdb`$$
DROP TRIGGER IF EXISTS `msgdb`.`Twit_BEFORE_INSERT` $$
USE `msgdb`$$
CREATE
DEFINER=CURRENT_USER
TRIGGER `msgdb`.`Twit_BEFORE_INSERT`
BEFORE INSERT ON `Twit`
FOR EACH ROW
BEGIN
SET NEW.created = NOW();
END$$


DELIMITER ;
