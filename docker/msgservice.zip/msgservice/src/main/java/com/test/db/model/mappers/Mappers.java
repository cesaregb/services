package com.test.db.model.mappers;

import com.test.db.model.dto.Follow;
import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by cesaregb on 1/12/17.
 */
public class Mappers {

	public static final class FollowMapper implements RowMapper<Follow> {

		public Follow mapRow(ResultSet rs, int rowNum) throws SQLException {
			Follow r = new Follow();
			r.setIdFollow(rs.getInt("idFollow"));
			r.setIdUser(rs.getInt("idUser"));
			r.setIdFollower(rs.getInt("idFollower"));
			return r;
		}
	}

	public static final class TwitMapper implements RowMapper<Twit> {
		public Twit mapRow(ResultSet rs, int rowNum) throws SQLException {
			Twit r = new Twit();
			r.setIdTwit(rs.getInt("idTwit"));
			r.setIdUser(rs.getInt("idUser"));
			r.setText(rs.getString("text"));
			r.setCreated(rs.getDate("created"));
			return r;
		}
	}


	public static final class UserMapper implements RowMapper<User> {

		// we may be able to use some mapper like orika to make dynamic mapping.
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User r = new User();
			r.setIdUser(rs.getInt("idUser"));
			r.setUsername(rs.getString("username"));
			r.setName(rs.getString("name"));
			r.setEmail(rs.getString("email"));
			r.setDeleted(rs.getInt("deleted"));
			return r;
		}
	}

}
