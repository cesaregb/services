package com.test.db.model.dao;

import com.test.exceptions.DBCustomException;

import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
public interface GenericDao<T, ID> {
	public T findById(ID id);
	public T save(T entity) throws DBCustomException;
	public T update(T entity) throws DBCustomException;
	public void delete(ID id) throws DBCustomException;
	public List<T> findAll();


}
