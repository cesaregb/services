package com.test.exceptions;

import javax.ws.rs.core.Response;

public class TestCustomException extends Exception {
	private static final long serialVersionUID = 1L;

	Response.Status status = Response.Status.INTERNAL_SERVER_ERROR;

	public TestCustomException(Response.Status status, String message) {
		super(message);
		this.status = status;
	}

	public TestCustomException(Response.Status status, String message, Exception e) {
		super(message, e);
		this.status = status;
	}

	public TestCustomException(String message) {
		super(message);
	}

	public TestCustomException(String message, Exception e) {
		super(message, e);
	}


	public TestCustomException(Exception e) {
		super(e);
	}

	public Response.Status getStatus() {
		return status;
	}

	public void setStatus(Response.Status status) {
		this.status = status;
	}
}
