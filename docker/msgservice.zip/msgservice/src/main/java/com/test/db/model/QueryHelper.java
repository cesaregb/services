package com.test.db.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by cesaregb on 1/10/17.
 */
public class QueryHelper {
	private static final String UPDATE_APPENDER = "=?, ";

	/**
	 * Helper to generate the SET field=?
	 * @param fields
	 * @return
	 */
	@Deprecated
	public static String getSetQuery(List<String> fields){
		return fields.stream()
				.filter(i -> !i.contains("id"))
				.collect(Collectors.joining(UPDATE_APPENDER)) + "=? ";
	}

	/**
	 * Query helper, not used yet.
	 * @param map
	 * @return
	 */

	@Deprecated
	public static String getQuery(HashMap<String, String> map){
		final String queryHelper = map.entrySet().stream()
				.filter(e->e.getValue() != null)
				.map(e->e.getKey() + "=?")
				.collect(Collectors.joining(" or "));

		List<Object> values = map.entrySet().stream()
				.filter(e->e.getValue() != null)
				.map(Map.Entry::getValue)
				.collect(Collectors.toList());

		return queryHelper;
	}

	public static String generateLike(String val) {
		return "%" + val + "%";
	}

}
