package com.test.services;

import com.test.db.model.dao.impl.UserDaoImp;
import com.test.db.model.dto.User;
import com.test.exceptions.DBCustomException;
import com.test.exceptions.TestCustomException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Created by cesaregb on 1/11/17.
 */
@Service
public class UserService {
	private final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

	@Resource
	private UserDaoImp userDAO;

	public User findById(int idUser) throws TestCustomException{
		try{
			return userDAO.findById(idUser);
		}catch(EmptyResultDataAccessException e){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "Element not found");
		}catch(Exception e){
			throw new TestCustomException(Response.Status.INTERNAL_SERVER_ERROR, "Error on the query... ");
		}
	}

	public List<User> find(int idUser, String username, String name, String email){
		LOGGER.info("[findUsers] idUser: {}, username: {}, name: {}, email: {}", idUser, username, name, email);
		List<User> result = null;
		if (idUser == 0 && username == null && name == null && email == null){
			result = userDAO.findAll();
		}else{
			result = userDAO.find(idUser, username, name, email);
		}
		// logic as a placeholder in case we require to filter the set of data.
		return result;
	}

	// overloading method
	public User save(String username, String name, String email) throws TestCustomException{
		User user = new User(0, username, name, email);
		return save(user);
	}
	public User save(User user) throws TestCustomException{
		try {
			return userDAO.save(user);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

	public User update(int idUser, String username, String name, String email) throws TestCustomException{
		if (idUser == 0){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "Id is required for an update");
		}
		User user = new User(idUser, username, name, email);
		return update(user);
	}

	public User update(User user) throws TestCustomException{
		try {
			return userDAO.update(user);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

	public void delete(Integer id) throws TestCustomException{
		try {
			userDAO.delete(id);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

	public int getIdUser(String userID) throws TestCustomException {
		int idUser = 0;
		if (StringUtils.isNumeric(userID)){
			idUser = Integer.valueOf(userID);
			if (this.findById(idUser) == null){
				throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
			}
		}else{
			List<User> users = this.find(0, userID, null, null);
			if (users == null || users.isEmpty()){
				throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
			}

			// we are validating at insertion time that we only have 1 user with that username
			// database may show more than 1, but it may be marked as deleted.
			idUser = users.get(0).getIdUser();
		}
		return idUser;
	}

}
