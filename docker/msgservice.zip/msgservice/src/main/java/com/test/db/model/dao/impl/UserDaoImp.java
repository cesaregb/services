package com.test.db.model.dao.impl;

import com.healthmarketscience.sqlbuilder.*;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbColumn;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSchema;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSpec;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;
import com.mysql.jdbc.PreparedStatement;
import com.test.db.model.QueryHelper;
import com.test.db.model.dao.GenericDao;
import com.test.db.model.dto.User;
import com.test.db.model.mappers.Mappers;
import com.test.exceptions.DBCustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
@Repository
public class UserDaoImp extends JdbcDaoSupport implements GenericDao<User, Integer> {
	private final Logger LOGGER = LoggerFactory.getLogger(UserDaoImp.class);
	private static final int DELETED_VALUE = 1;
	// Usage of QueryBuilder to demostrate the "possible" usage for building dynamic queries.
	private DbSpec spec = new DbSpec();
	private DbSchema schema = spec.addDefaultSchema();
	private DbTable userTable = schema.addTable("User");
	private DbColumn idUser = userTable.addColumn("idUser", "number", null);
	private DbColumn username = userTable.addColumn("username", "varchar", 255);
	private DbColumn name = userTable.addColumn("name", "varchar", 255);
	private DbColumn email = userTable.addColumn("email", "varchar", 255);
	private DbColumn deleted = userTable.addColumn("deleted", "number", null);

	@Autowired
	private DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public User findById(Integer id) {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(userTable);
		sq.addCondition(BinaryCondition.equalTo(idUser, "?"));
		// include skip deleted...
		sq.addCondition(BinaryCondition.equalTo(deleted, "0"));

		final String sql = sq.validate().toString().replaceAll("'", "");
		LOGGER.info("Get entity by Id: {} ", id);
		try{
			return getJdbcTemplate().queryForObject(sql,
					new Object[]{id},
					new Mappers.UserMapper());
		}catch (Exception e){
			LOGGER.error("Error getting element", e);
			return null;
		}
	}

	@Override
	public User save(User entity) throws DBCustomException {
		if (!findByUsernameEmails(entity.getUsername(), entity.getEmail()).isEmpty()) {
			LOGGER.error("User exit with the same email {}, or username {}");
			throw new DBCustomException("A User exist with that email and/or username ");
		}
		LOGGER.info("Valid User");

		final String sql = new InsertQuery(userTable)
				.addColumn(username, "?")
				.addColumn(name, "?")
				.addColumn(email, "?")
				.validate().toString().replaceAll("'", "");

		KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update(
				connection -> {
					PreparedStatement ps =
							(PreparedStatement) connection.prepareStatement(sql, new String[] {"idUser"});
					ps.setString(1, entity.getUsername());
					ps.setString(2, entity.getName());
					ps.setString(3, entity.getEmail());
					return ps;
				},
				keyHolder);

		entity.setIdUser(keyHolder.getKey().intValue());
		return entity;
	}

	@Override
	public User update(User entity) throws DBCustomException {
		if (findById(entity.getIdUser()) == null) {
			throw new DBCustomException("User with ID [" + entity.getIdUser() + "] doesn't exist");
		}

		final String sql = new UpdateQuery(userTable)
				.addSetClause(username, "?")
				.addSetClause(name, "?")
				.addSetClause(email,"?")
				.addCondition(BinaryCondition.equalTo(idUser, "?"))
				.validate().toString().replaceAll("'", "");

		getJdbcTemplate().update(sql,
				entity.getUsername(), entity.getName(), entity.getEmail(), entity.getIdUser());

		return entity;
	}

	/**
	 * Flaging elements as "deleted" this to:
	 *  Avoid lousing data.
	 *  Avoid reindexing of the table.
	 *      we can run a batch for cleaning the data, this would reduce the time of "reindexing"
	 * @param id
	 * @throws DBCustomException
	 */
	@Override
	public void delete(Integer id) throws DBCustomException {
		final String sql = new UpdateQuery(userTable)
				.addSetClause(deleted, "?")
				.addCondition(BinaryCondition.equalTo(idUser, "?"))
				.validate().toString().replaceAll("'", "");
		LOGGER.info("Query: {}", sql);

		getJdbcTemplate().update(sql, DELETED_VALUE, id);
	}


	@Override
	public List<User> findAll() {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(userTable);
		// include skip deleted...
		sq.addCondition(BinaryCondition.equalTo(deleted, "0"));

		final String sql = sq.validate().toString().replaceAll("'", "");

		LOGGER.info("get all entities");
		return getJdbcTemplate().query(sql, new Mappers.UserMapper());
	}


	/**
	 * usage of query builder to create a dynamic query without the boilerplate of the ands/ors.
	 * @param _idUser
	 * @param _username
	 * @param _name
	 * @param _email
	 * @return
	 */
	public List<User> find(int _idUser, String _username, String _name, String _email) {
		SelectQuery sq = new SelectQuery();
		List<Object> objs = new ArrayList<>();

		// we could use a dynamic sql builder to perform this action, I couldn't found anyone that worked.
		sq.addAllTableColumns(userTable);
		ComboCondition cc = ComboCondition.or();
		if (_idUser > 0) {
			cc.addCondition(BinaryCondition.equalTo(idUser, "?"));
			objs.add(_idUser);
		}
		if (_username != null) {
			cc.addCondition(BinaryCondition.like(username, "?"));
			objs.add(QueryHelper.generateLike(_username));
		}
		if (_name != null) {
			cc.addCondition(BinaryCondition.like(name, "?"));
			objs.add(QueryHelper.generateLike(_name));
		}
		if (_email != null) {
			cc.addCondition(BinaryCondition.like(email, "?"));
			objs.add(QueryHelper.generateLike(_email));
		}
		sq.addCondition(cc);
		sq.addCondition(BinaryCondition.equalTo(deleted, "0"));
		String sql = sq.validate().toString().replaceAll("'", "");

		LOGGER.info("Query: {}, obj size: {}", sql, String.join(", " + objs));
		List<User> result =
				getJdbcTemplate().query(sql,
						objs.toArray(new Object[objs.size()]),
						new Mappers.UserMapper());

		return result;
	}

	public List<User> findByUsernameEmails(String _username, String _email) {
		SelectQuery sq = new SelectQuery();
		List<Object> objs = new ArrayList<>();

		// we could use a dynamic sql builder to perform this action, I couldn't found anyone that worked.
		sq.addAllTableColumns(userTable);
		ComboCondition cc = ComboCondition.or();
		if (_username != null) {
			cc.addCondition(BinaryCondition.equalTo(username, "?"));
			objs.add(_username);
		}
		if (_email != null) {
			cc.addCondition(BinaryCondition.equalTo(email, "?"));
			objs.add(_email);
		}
		sq.addCondition(cc);
		sq.addCondition(BinaryCondition.equalTo(deleted, "0"));
		String sql = sq.validate().toString().replaceAll("'", "");

		LOGGER.info("Query: {}, obj size: {}", sql, String.join(", " + objs));
		List<User> result =
				getJdbcTemplate().query(sql,
						objs.toArray(new Object[objs.size()]),
						new Mappers.UserMapper());

		return result;
	}

}


