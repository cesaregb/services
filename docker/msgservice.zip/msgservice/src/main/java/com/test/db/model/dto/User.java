package com.test.db.model.dto;

/**
 * Created by cesaregb on 1/9/17.
 */
public class User {
	private int idUser;
	private String username;
	private String name;
	private String email;
	private int deleted;

	public User(){}
	public User(int idUser, String username, String name, String email) {
		this.idUser = idUser;
		this.username = username;
		this.name = name;
		this.email = email;
	}

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getDeleted() {
		return deleted;
	}

	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("User{");
		sb.append("idUser=").append(idUser);
		sb.append(", username='").append(username).append('\'');
		sb.append(", name='").append(name).append('\'');
		sb.append(", email='").append(email).append('\'');
		sb.append(", deleted=").append(deleted);
		sb.append('}');
		return sb.toString();
	}
}
