package com.test.rest.api.impl;

import com.test.db.model.dto.Twit;
import com.test.exceptions.TestCustomException;
import com.test.rest.api.AbstractServices;
import com.test.services.TwitService;
import com.test.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
@RestController
public class TwitController extends AbstractServices {
	private final Logger LOGGER = LoggerFactory.getLogger(TwitController.class);

	@Resource
	private TwitService twitService;

	@Resource
	private UserService userService;

	@RequestMapping(value = "/user/{userID}/twit", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Twit>> getTwit(@PathVariable("userID") String userID,
	                                          @RequestParam(value = "text", required = false) String text) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		List<Twit> listTwits = twitService.find(idUser, text);
		return new ResponseEntity<>(listTwits, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{idUser}/twit/{idTwit}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Twit> getTwitById(@PathVariable("idUser") int idUser, @PathVariable("idTwit") int id) throws TestCustomException {
		if (userService.findById(idUser) == null){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
		}
		return new ResponseEntity<>(twitService.findById(id), HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{idUser}/twit", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Twit> saveTwit(@PathVariable("idUser") int idUser, @RequestBody Twit input) throws TestCustomException {
		if (userService.findById(idUser) == null){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
		}
		input.setIdUser(idUser);

		Twit twit = twitService.twit(input);
		return new ResponseEntity<>(twit, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/user/{idUser}/twit", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<Twit> updateTwit(@PathVariable("idUser") int idUser, @RequestBody Twit input) throws TestCustomException {
		if (userService.findById(idUser) == null){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
		}
		input.setIdUser(idUser);
		twitService.update(input);
		return new ResponseEntity<>(input, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{idUser}/twit/{id}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity deleteTwit(@PathVariable("idUser") int idUser, @PathVariable("id") int id) throws TestCustomException {
		if (userService.findById(idUser) == null){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid");
		}
		twitService.delete(id);
		return new ResponseEntity(id, HttpStatus.OK);

	}
}
