package com.test.rest.api.impl;

import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import com.test.exceptions.TestCustomException;
import com.test.rest.api.AbstractServices;
import com.test.services.FollowService;
import com.test.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
@RestController
public class UserController extends AbstractServices {
	private final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Resource
	private UserService userService;

	@Resource
	private FollowService followService;

	@RequestMapping(value = "/user", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<User>> getUser(@RequestParam(value = "idUser", required = false) Integer idUser,
	                                          @RequestParam(value = "username", required = false) String username,
	                                          @RequestParam(value = "name", required = false) String name,
	                                          @RequestParam(value = "email", required = false) String email) {

		// clean up idUser for usage.
		idUser = (idUser==null)? 0 : idUser;
		List<User> listUsers = userService.find(idUser, username, name, email);
		return new ResponseEntity<>(listUsers, HttpStatus.OK);

	}

	@RequestMapping(value = "/user/{idUser}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<User> getUserById(@PathVariable("idUser") int idUser) throws TestCustomException {
		return new ResponseEntity<>(userService.findById(idUser), HttpStatus.OK);
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<User> saveUser(@RequestBody User input) throws TestCustomException {
		User user = userService.save(input);
		return new ResponseEntity<>(user, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/user", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<User> updateUser(@RequestBody User input) throws TestCustomException {
		userService.update(input);
		return new ResponseEntity<>(input, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{idUser}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity deleteUser(@PathVariable("idUser") int idUser) throws TestCustomException {
		userService.delete(idUser);
		return new ResponseEntity(idUser, HttpStatus.OK);

	}

	@RequestMapping(value = "/user/{userID}/timeline", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Twit>> userTimeline(@PathVariable("userID") String userID,
	                                               @RequestParam(value = "text", required = false) String text) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		List<Twit> listTwits = followService.getTimeline(idUser, text);
		return new ResponseEntity<>(listTwits, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{userID}/followers", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<User>> followers(@PathVariable("userID") String userID) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		List<User> list = followService.followers(idUser);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{userID}/following", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<User>> following(@PathVariable("userID") String userID) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		List<User> list = followService.following(idUser);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/user/{userID}/follow/{followID}", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity follow(@PathVariable("userID") String userID,
	                                         @PathVariable("followID") String followID) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		int idFollow = userService.getIdUser(userID);
		if (idFollow == 0 || idUser == 0){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "Information not valid.");
		}
		followService.follow(idUser, idFollow);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/user/{userID}/unfollow/{followID}", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity unfollow(@PathVariable("userID") String userID,
	                             @PathVariable("followID") String followID) throws TestCustomException {
		int idUser = userService.getIdUser(userID);
		int idFollow = userService.getIdUser(userID);
		if (idFollow == 0 || idUser == 0){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "Information not valid.");
		}
		followService.unfollow(idUser, idFollow);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
