package com.test.config;

/*
 * Configuration initial point. 
 * setting the "paths" that spring is going to look for configuration, 
 * note that if we have a package within conf ie com.test.conf.security is going to be added automaticately
 * */
//@Configuration
//@ComponentScan({
//		"com.test.config"
//})
public class SpringRootConfig { }
