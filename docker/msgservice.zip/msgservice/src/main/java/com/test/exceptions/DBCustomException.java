package com.test.exceptions;

/**
 * Exception used as a marker to propagate exceptions from the database.
 */
public class DBCustomException extends Exception {
	private static final long serialVersionUID = 1L;

	public DBCustomException(String message) {
		super(message);
	}

	public DBCustomException(String message, Exception e) {
		super(message, e);
	}


	public DBCustomException(Exception e) {
		super(e);
	}
}
