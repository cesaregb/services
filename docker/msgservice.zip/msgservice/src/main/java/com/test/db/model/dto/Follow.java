package com.test.db.model.dto;

/**
 * Created by cesaregb on 1/12/17.
 */
public class Follow {
	private int idFollow;
	private int idUser;
	private int idFollower;

	public Follow(){}
	public Follow(int idFollow, int idUser, int idFollower) {
		this.idFollow = idFollow;
		this.idUser = idUser;
		this.idFollower = idFollower;
	}

	public int getIdFollow() {
		return idFollow;
	}

	public void setIdFollow(int idFollow) {
		this.idFollow = idFollow;
	}

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public int getIdFollower() {
		return idFollower;
	}

	public void setIdFollower(int idFollower) {
		this.idFollower = idFollower;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("Follow{");
		sb.append("idFollow=").append(idFollow);
		sb.append(", idUser=").append(idUser);
		sb.append(", idFollower=").append(idFollower);
		sb.append('}');
		return sb.toString();
	}
}
