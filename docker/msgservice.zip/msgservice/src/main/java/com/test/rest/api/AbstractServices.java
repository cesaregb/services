package com.test.rest.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Parent class to "Controllers" (endpoints) to control the parent path "/api/v#"
 */

@RestController
@RequestMapping(value = "/api", produces = "application/json")
public class AbstractServices {
	
}
