package com.test.config.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Created by cesaregb on 1/12/17.
 */
public class SecurityWebApplicationInitializer
		extends AbstractSecurityWebApplicationInitializer {
}
