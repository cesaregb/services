package com.test.services;

import com.test.db.model.dao.impl.TwitDaoImp;
import com.test.db.model.dao.impl.UserDaoImp;
import com.test.db.model.dto.Twit;
import com.test.exceptions.DBCustomException;
import com.test.exceptions.TestCustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Created by cesaregb on 1/11/17.
 */

@Service
public class TwitService {
	private final Logger LOGGER = LoggerFactory.getLogger(TwitService.class);

	@Resource
	private TwitDaoImp twitDAO;

	@Resource
	private UserDaoImp userDAO;

	public Twit findById(int idTwit) throws TestCustomException{
		try{
			return twitDAO.findById(idTwit);
		}catch(Exception e){
			throw new TestCustomException(Response.Status.INTERNAL_SERVER_ERROR, "Error on the query... ");
		}
	}

	public List<Twit> find(int idUser, String text){
		LOGGER.info("[findTwits] idUser: {}, text: {}", idUser, text);
		List<Twit> result = null;
		if (idUser == 00 && text == null){
			result = twitDAO.findAll();
		}else{
			result = twitDAO.find(idUser, text);
		}
		return result;
	}

	// overloading method
	public Twit twit(int idUser, String text) throws TestCustomException{
		Twit twit = new Twit(0, idUser, text);
		return twit(twit);
	}
	public Twit twit(Twit twit) throws TestCustomException{
		if (userDAO.findById(twit.getIdUser()) == null){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "User not valid.");
		}

		try {
			return twitDAO.save(twit);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

	public Twit update(int idTwit, int idUser, String text) throws TestCustomException{
		if (idTwit == 0){
			throw new TestCustomException(Response.Status.BAD_REQUEST, "Id is required for an update");
		}
		Twit twit = new Twit(idTwit, idUser, text);
		return update(twit);
	}

	public Twit update(Twit twit) throws TestCustomException{
		try {
			return twitDAO.update(twit);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

	public void delete(int id) throws TestCustomException{
		try {
			twitDAO.delete(id);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
	}

}
