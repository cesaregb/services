package com.test.services;

import com.test.db.model.dao.impl.FollowDaoImp;
import com.test.db.model.dto.Follow;
import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import com.test.exceptions.DBCustomException;
import com.test.exceptions.TestCustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 * Created by cesaregb on 1/11/17.
 */

@Service
public class FollowService {
	private final Logger LOGGER = LoggerFactory.getLogger(FollowService.class);

	@Resource
	private FollowDaoImp followDao;

	public boolean follow(int idUser, int idFollower) throws TestCustomException {
		if (!followDao.findByIds(idUser, idFollower).isEmpty()){
			return true;
		}

		Follow f = new Follow(0, idUser, idFollower);
		try {
			followDao.save(f);
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}

		return true;
	}

	public boolean unfollow(int idUser, int idFollower) throws TestCustomException {
		List<Follow> list = followDao.findByIds(idUser, idFollower);
		if (list.isEmpty()){
			return true;
		}

		Follow f = list.get(0);
		try {
			followDao.delete(f.getIdFollow());
		} catch (DBCustomException e) {
			throw new TestCustomException(Response.Status.BAD_REQUEST, e.getMessage());
		}
		return true;
	}

	public List<Twit> getTimeline(int idUser, String text){
		if (text !=  null && !text.isEmpty()) {
			return followDao.getTwits(idUser, text);
		}else{
			return followDao.getTwits(idUser);
		}
	}

	public List<User> followers(int idUser) {
		return followDao.getFollowers(idUser);

	}

	public List<User> following(int idUser){
		return followDao.getFollowing(idUser);
	}

}
