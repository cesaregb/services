package com.test.config.spring;

import com.test.db.model.dao.impl.TwitDaoImp;
import com.test.db.model.dao.impl.UserDaoImp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/**
 * Created by cesaregb on 1/9/17.
 */

@Configuration
public class SpringJDBCConfiguration {

	/*
	* We could load these properties from the resources.
	* with spring we could inject either the environment or the string directly.
	* this is applicable for profiles as well.

	@Resource
	private Environment env;

	@Value("${db.url}")
	private String dbUrl;

	But we are going to read these properties (if any) from env vars,
	this to make sure the database information is secured within the system environment.

	As well we could

	* */

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		final String dbUrl = (System.getenv("DB_URL")!=null)?System.getenv("DB_URL"):"jdbc:mysql://localhost:3306/msgdb";
		final String dbUser = (System.getenv("DB_USER")!=null)?System.getenv("DB_USER"):"root";
		final String dbPassword = (System.getenv("DB_PASSWORD")!=null)?System.getenv("DB_PASSWORD"):"Welcome1";

		dataSource.setUrl(dbUrl);
		dataSource.setUsername(dbUser);
		dataSource.setPassword(dbPassword);

		//H2 database
		// TODO apply h2 for testing..
        /*
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("jdbc:h2:tcp://localhost/~/test");
        dataSource.setUsername("sa");
        dataSource.setPassword("");*/
		return dataSource;
	}

	@Bean
	public UserDaoImp userDAO(){
		UserDaoImp dao = new UserDaoImp();
		dao.setDataSource(dataSource());
		return dao;
	}

	@Bean
	public TwitDaoImp twitDaoImp(){
		TwitDaoImp dao = new TwitDaoImp();
		dao.setDataSource(dataSource());
		return dao;
	}
}
