package com.test.db.model.dao.impl;

import com.healthmarketscience.sqlbuilder.*;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbColumn;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSchema;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSpec;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;
import com.mysql.jdbc.PreparedStatement;
import com.test.db.model.QueryHelper;
import com.test.db.model.dao.GenericDao;
import com.test.db.model.dto.Twit;
import com.test.db.model.mappers.Mappers;
import com.test.exceptions.DBCustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
@Repository
public class TwitDaoImp extends JdbcDaoSupport implements GenericDao<Twit, Integer> {
	private final Logger LOGGER = LoggerFactory.getLogger(TwitDaoImp.class);

	// Usage of QueryBuilder to demostrate the "possible" usage for building dynamic queries.
	private DbSpec spec = new DbSpec();
	private DbSchema schema = spec.addDefaultSchema();
	private DbTable twitTable = schema.addTable("Twit");
	private DbColumn idTwit = twitTable.addColumn("idTwit", "number", null);
	private DbColumn idUser = twitTable.addColumn("idUser", "number", null);
	private DbColumn text = twitTable.addColumn("text", "varchar", 255);
	private DbColumn date = twitTable.addColumn("created", "timestamp", 255);

	@Autowired
	private DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public Twit findById(Integer id) {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(twitTable);
		sq.addCondition(BinaryCondition.equalTo(idTwit, "?"));

		final String sql = sq.validate().toString().replaceAll("'", "");
		LOGGER.info("Get entity by Id: {} ", id);

		try{
			return getJdbcTemplate().queryForObject(sql,
					new Object[]{id},
					new Mappers.TwitMapper());
		}catch (Exception e){
			LOGGER.error("Error getting element", e);
			return null;
		}
	}

	@Override
	public Twit save(Twit entity) throws DBCustomException {
		final String sql = new InsertQuery(twitTable)
				.addColumn(idUser, "?")
				.addColumn(text, "?")
				.validate().toString().replaceAll("'", "");


		KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update(
				connection -> {
					PreparedStatement ps =
							(PreparedStatement) connection.prepareStatement(sql, new String[] {"idTwit"});
					ps.setInt(1, entity.getIdUser());
					ps.setString(2, entity.getText());
					return ps;
				},
				keyHolder);

		entity.setIdTwit(keyHolder.getKey().intValue());
		return entity;
	}

	@Override
	public Twit update(Twit entity) throws DBCustomException {
		final String sql = new UpdateQuery(twitTable)
				.addSetClause(text, "?")
				.addCondition(BinaryCondition.equalTo(idTwit, "?"))
				.validate().toString().replaceAll("'", "");

		getJdbcTemplate().update(sql,
				entity.getText(), entity.getIdTwit());

		return entity;
	}

	@Override
	public void delete(Integer id) throws DBCustomException {
		final String sql = new DeleteQuery(twitTable)
				.addCondition(BinaryCondition.equalTo(idTwit, "?"))
				.validate().toString().replaceAll("'", "");
		LOGGER.info("Query: {}", sql);
		getJdbcTemplate().update(sql, id);
	}

	@Override
	public List<Twit> findAll() {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(twitTable);
		final String sql = sq.validate().toString().replaceAll("'", "");
		return getJdbcTemplate().query(sql, new Mappers.TwitMapper());
	}

	public List<Twit> findByIdUser(Integer _idUser) {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(twitTable);
		sq.addCondition(BinaryCondition.equalTo(idUser, "?"));
		final String sql = sq.validate().toString().replaceAll("'", "");

		return getJdbcTemplate().query(sql, new Object[]{_idUser}, new Mappers.TwitMapper());
	}

	public List<Twit> find(int _idUser, String _text) {
		SelectQuery sq = new SelectQuery();
		List<Object> objs = new ArrayList<>();

		sq.addAllTableColumns(twitTable);
		ComboCondition cc = ComboCondition.or();
		if (_idUser > 0) {
			cc.addCondition(BinaryCondition.equalTo(idUser, "?"));
			objs.add(_idUser);
		}
		if (_text != null) {
			cc.addCondition(BinaryCondition.like(text, "?"));
			objs.add(QueryHelper.generateLike(_text));
		}

		sq.addCondition(cc);
		String sql = sq.validate().toString().replaceAll("'", "");

		LOGGER.info("Query: {}, obj size: {}", sql, String.join(", " + objs));
		List<Twit> result =
				getJdbcTemplate().query(sql,
						objs.toArray(new Object[objs.size()]),
						new Mappers.TwitMapper());

		return result;
	}


	/**
	 * Mapper/Converter
	 */

}


