package com.test.exceptions;

import com.test.vo.ErrorVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	private final Logger LOGGER = LoggerFactory.getLogger(RestResponseEntityExceptionHandler.class);

    @ExceptionHandler(value = { Exception.class })
    protected ResponseEntity<Object> handleConflict(Exception ex, WebRequest request) {
	    LOGGER.error("Error: " , ex);
    	ErrorVo error = new ErrorVo(ErrorVo.GENERAL_ERROR, ex.getMessage());
    	return handleExceptionInternal(ex, error, 
    			new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
    
    @ExceptionHandler(value = { RuntimeException.class })
    protected ResponseEntity<Object> handleRTEConflict(RuntimeException ex, WebRequest request) {
	    LOGGER.error("Error: " , ex);
    	ErrorVo error = new ErrorVo(ErrorVo.GENERAL_ERROR, ex.getMessage());
    	return handleExceptionInternal(ex, error, 
    			new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
    
    @ExceptionHandler(value = { TestCustomException.class })
    protected ResponseEntity<Object> handleConflictSOD(TestCustomException ex, WebRequest request) {
	    LOGGER.error("Error: " , ex);
    	ErrorVo error = new ErrorVo(ErrorVo.GENERAL_ERROR, ex.getMessage());
	    HttpStatus code = (ex.getStatus() != null)? HttpStatus.valueOf(ex.getStatus().getStatusCode()) :HttpStatus.INTERNAL_SERVER_ERROR;
    	return handleExceptionInternal(ex, error, 
    			new HttpHeaders(), code, request);
    }
    
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex,
                HttpHeaders headers, HttpStatus status, WebRequest request){
	    LOGGER.error("Error: " , ex);
    	ErrorVo error = new ErrorVo(ErrorVo.GENERAL_ERROR, "404 no resource found");
    	return handleExceptionInternal(ex, error, 
    			new HttpHeaders(), HttpStatus.NOT_FOUND, request);
    }
}