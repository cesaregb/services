package com.test.db.model.dto;

import java.util.Date;

/**
 * Created by cesaregb on 1/12/17.
 */
public class Twit {
	private int idTwit;
	private int idUser;
	private String text;
	private Date created;

	public Twit(){}
	public Twit(int idTwit, int idUser, String text) {
		this.idTwit = idTwit;
		this.idUser = idUser;
		this.text = text;
	}

	public int getIdTwit() {
		return idTwit;
	}

	public void setIdTwit(int idTwit) {
		this.idTwit = idTwit;
	}

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("TwitDto{");
		sb.append("idTwit=").append(idTwit);
		sb.append(", idUser=").append(idUser);
		sb.append(", text='").append(text).append('\'');
		sb.append(", created=").append(created);
		sb.append('}');
		return sb.toString();
	}
}
