package com.test.db.model.dao.impl;

import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.DeleteQuery;
import com.healthmarketscience.sqlbuilder.InsertQuery;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbColumn;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSchema;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSpec;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;
import com.mysql.jdbc.PreparedStatement;
import com.test.db.model.dao.GenericDao;
import com.test.db.model.dto.Follow;
import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import com.test.db.model.mappers.Mappers;
import com.test.exceptions.DBCustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.List;

/**
 * Created by cesaregb on 1/9/17.
 */
@SuppressWarnings("SqlDialectInspection")
@Repository
public class FollowDaoImp extends JdbcDaoSupport implements GenericDao<Follow, Integer> {
	private final Logger LOGGER = LoggerFactory.getLogger(FollowDaoImp.class);

	// Usage of QueryBuilder to demostrate the "possible" usage for building dynamic queries.
	private DbSpec spec = new DbSpec();
	private DbSchema schema = spec.addDefaultSchema();
	private DbTable followTable = schema.addTable("Follow");
	private DbColumn idFollow = followTable.addColumn("idFollow", "number", null);
	private DbColumn idUser = followTable.addColumn("idUser", "number", null);
	private DbColumn idFollower = followTable.addColumn("idFollower", "number", null);

	@Autowired
	private DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public Follow findById(Integer id) {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(followTable);
		sq.addCondition(BinaryCondition.equalTo(idFollow, "?"));

		final String sql = sq.validate().toString().replaceAll("'", "");
		try{
			return getJdbcTemplate().queryForObject(sql,
					new Object[]{id},
					new Mappers.FollowMapper());
		}catch (Exception e){
			LOGGER.error("Error getting element", e);
			return null;
		}
	}

	@Override
	public Follow save(Follow entity) throws DBCustomException {
		final String sql = new InsertQuery(followTable)
				.addColumn(idUser, "?")
				.addColumn(idFollower, "?")
				.validate().toString().replaceAll("'", "");

		KeyHolder keyHolder = new GeneratedKeyHolder();
		getJdbcTemplate().update(
				connection -> {
					PreparedStatement ps =
							(PreparedStatement) connection.prepareStatement(sql, new String[] {"idFollow"});
					ps.setInt(1, entity.getIdUser());
					ps.setInt(2, entity.getIdFollower());
					return ps;
				},
				keyHolder);

		entity.setIdFollow(keyHolder.getKey().intValue());
		return entity;
	}

	@Override
	public Follow update(Follow entity) throws DBCustomException {
		return entity;
	}

	@Override
	public void delete(Integer id) throws DBCustomException {
		final String sql = new DeleteQuery(followTable)
				.addCondition(BinaryCondition.equalTo(idFollow, "?"))
				.validate().toString().replaceAll("'", "");
		getJdbcTemplate().update(sql, id);
	}

	@Override
	public List<Follow> findAll() {
		SelectQuery sq = new SelectQuery();
		sq.addAllTableColumns(followTable);
		final String sql = sq.validate().toString().replaceAll("'", "");
		return getJdbcTemplate().query(sql, new Mappers.FollowMapper());
	}

	public List<Follow> findByIds(int idUser, int idFollower){
		String sql = "Select f.* from Follow as f where f.idUser=? and f.idFollower=?";
		return getJdbcTemplate().query(sql, new Object[]{idUser, idFollower}, new Mappers.FollowMapper());
	}

	public List<User> getFollowers(int _idUser) {
		final String sql = "Select u.* from User as u, Follow as f where f.idUser=? and f.idFollower=u.idUser";
		return getJdbcTemplate().query(sql, new Object[]{_idUser}, new Mappers.UserMapper());
	}

	public List<User> getFollowing(int _idUser) {
		final String sql = "Select u.* from User as u, Follow as f where f.idUser=u.idUser and f.idFollower=?";
		return getJdbcTemplate().query(sql, new Object[]{_idUser}, new Mappers.UserMapper());
	}

	public List<Twit> getTwits(int _idUser) {
		final String sql = "Select t.* from Twit as t where t.idUser IN (Select f.idUSer from User as u, Follow as f where f.idUser=u.idUser and f.idFollower=?) or t.idUser=?";
		return getJdbcTemplate().query(sql, new Object[]{_idUser, _idUser}, new Mappers.TwitMapper());
	}

	public List<Twit> getTwits(int _idUser, String text) {
		final String sql = "Select t.* from Twit as t where t.idUser IN (Select f.idUSer from User as u, Follow as f where f.idUser=u.idUser and f.idFollower=?) or t.idUser=? and t.text like '%?%'";
		return getJdbcTemplate().query(sql, new Object[]{_idUser, _idUser, text}, new Mappers.TwitMapper());
	}

}


