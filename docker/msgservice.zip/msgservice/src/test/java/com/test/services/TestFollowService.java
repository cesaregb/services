package com.test.services;

import com.test.SpringTestConfiguration;
import com.test.db.model.dao.impl.UserDaoImp;
import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import com.test.exceptions.TestCustomException;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by cesaregb on 1/11/17.
 */
public class TestFollowService extends SpringTestConfiguration {

	private final Logger LOGGER = LoggerFactory.getLogger(TestFollowService.class);

	@Autowired
	private TwitService twitService;

	@Autowired
	private UserDaoImp userDAO;

	@Autowired
	private FollowService followService;

	@Autowired
	private UserService userService;

	@Test
	public void testFollow() throws Exception{
		clearUsers(); // Testing making sure doesnt exit ...

		String data = "test1";
		User u1 = userDAO.save(new User(0, data, data, data));
		data = "test2";
		User u2 = userDAO.save(new User(0, data, data, data));

		twitService.twit(u1.getIdUser(), "twit1");
		twitService.twit(u1.getIdUser(), "twit2");

		twitService.twit(u2.getIdUser(), "abcd 1");
		twitService.twit(u2.getIdUser(), "abcd 2");

		followService.follow(u1.getIdUser(), u2.getIdUser());
		List<Twit> timeline = followService.getTimeline(u2.getIdUser(), null);
		LOGGER.info("**************************");
		timeline.forEach(t-> LOGGER.info("twit: {} ", t.toString()));
		Assert.assertTrue("List should contain 4 elements", timeline.size() == 4);

		List<User> followers = followService.followers(u1.getIdUser());
		LOGGER.info("**************************");
		followers.forEach(u->LOGGER.info("follower: {}", u.toString()));
		Assert.assertTrue("Follower list should contain 1 elements", followers.size() == 1);

		List<User> following = followService.following(u2.getIdUser());
		LOGGER.info("**************************");
		followers.forEach(u->LOGGER.info("following: {}", u.toString()));
		Assert.assertTrue("Follower list should contain 1 elements", following.size() == 1);

		followService.unfollow(u1.getIdUser(), u2.getIdUser());
		timeline = followService.getTimeline(u2.getIdUser(), null);
		LOGGER.info("**************************");
		timeline.forEach(t-> LOGGER.info("twit: {} ", t.toString()));
		Assert.assertTrue("List should contain 2 elements", timeline.size() == 2);

		followers = followService.followers(u1.getIdUser());
		LOGGER.info("**************************");
		followers.forEach(u->LOGGER.info("follower: {}", u.toString()));
		Assert.assertTrue("Follower list should contain 0 elements", followers.size() == 0);

		following = followService.following(u2.getIdUser());
		LOGGER.info("**************************");
		followers.forEach(u->LOGGER.info("following: {}", u.toString()));
		Assert.assertTrue("Follower list should contain 1 elements", following.size() == 0);

		clearUsers();
	}

	private void clearUsers() {
		// try using existing one if any...
		List<User> list = userService.find(0, "test", null, "test");
		list.forEach(t->{
			try {
				userService.delete(t.getIdUser());
			} catch (TestCustomException e) {
				e.printStackTrace();
			}
		});
	}

}
