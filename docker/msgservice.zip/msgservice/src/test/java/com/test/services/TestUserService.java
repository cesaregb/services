package com.test.services;

import com.test.SpringTestConfiguration;
import com.test.db.model.dto.User;
import com.test.exceptions.TestCustomException;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

/**
 * Created by cesaregb on 1/11/17.
 */
public class TestUserService extends SpringTestConfiguration {
	private static final String SOME_OTHER_TEXT = "some other test";
	private final Logger LOGGER = LoggerFactory.getLogger(TestUserService.class);

	private String id = UUID.randomUUID().toString();

	@Autowired
	private UserService userService;

	@Test
	public void testInsert() throws Exception{
		deleteUsers();
		User user = saveUser();
		user = userService.findById(user.getIdUser());
		Assert.assertTrue("findById should not throw exception...", user.getIdUser() > 0);
		deleteUsers();
	}

	@Test
	public void testFind() throws TestCustomException {
		saveUser();
		List<User> list = userService.find(0, id, "name", "email");
		Assert.assertTrue("List should contain +1 item", list.size() >= 1);
		list.forEach(i->LOGGER.info("item {}" , i));
		deleteUsers();
	}

	@Test
	public void testUpdate() throws Exception{
		saveUser();
		List<User> list = userService.find(0, id, null, null);
		id = "changed-Username";
		list.forEach(t -> {
			try {
				userService.update(t.getIdUser(), id, t.getName(), t.getEmail());

				User user = userService.findById(t.getIdUser());
				Assert.assertTrue("Entity should contain the updates ", user.getUsername().equals("changed-Username"));
			} catch (TestCustomException e) {
				// do nothing..
				e.printStackTrace();
			}
		});
		deleteUsers();
	}

	@Test
	public void testDelete() throws Exception{
		deleteUsers();
	}

	private User saveUser() throws TestCustomException {
		User user = userService.save(id, "name", "email");
		LOGGER.info(" t: {}", user.toString());
		Assert.assertTrue("Element should contain and ID", user.getIdUser() > 0);
		return user;
	}

	private void deleteUsers() {
		// try using existing one if any...
		List<User> list = userService.find(0, id, null, null);
		list.forEach(t->{
			try {
				userService.delete(t.getIdUser());
			} catch (TestCustomException e) {
				e.printStackTrace();
			}
		});

		list = userService.find(0, id, null, null);
		Assert.assertTrue("List should contain 0 item", list.isEmpty());
	}

}
