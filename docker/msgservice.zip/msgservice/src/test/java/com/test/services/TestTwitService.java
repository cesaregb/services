package com.test.services;

import com.test.SpringTestConfiguration;
import com.test.db.model.dao.impl.UserDaoImp;
import com.test.db.model.dto.Twit;
import com.test.db.model.dto.User;
import com.test.exceptions.TestCustomException;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by cesaregb on 1/11/17.
 */
public class TestTwitService extends SpringTestConfiguration {

	private static final String SOME_OTHER_TEXT = "some other test";
	private final Logger LOGGER = LoggerFactory.getLogger(TestTwitService.class);

	@Autowired
	private TwitService twitService;

	@Resource
	private UserDaoImp userDAO;

	@Test
	public void testInsert() throws Exception{
		Twit twit = saveTwit();

		twit = twitService.findById(twit.getIdTwit());
		Assert.assertTrue("findById should not throw exception...", twit.getIdTwit() > 0);
		deleteTwits();
	}

	@Test
	public void testFind() throws TestCustomException {
		saveTwit();
		List<Twit> list = twitService.find(0, "test");
		Assert.assertTrue("List should contain +1 item", list.size() >= 1);
		list.forEach(i->LOGGER.info("item {}" , i));
		deleteTwits();
	}

	@Test
	public void testUpdate() throws Exception{
		saveTwit();
		List<Twit> list = twitService.find(0, "This is a test");
		list.forEach(t -> {
			try {
				twitService.update(t.getIdTwit(), t.getIdUser(), SOME_OTHER_TEXT);
				Twit twit = twitService.findById(t.getIdTwit());
				Assert.assertTrue("Entity should contain the updates ", twit.getText().equals(SOME_OTHER_TEXT));
			} catch (TestCustomException e) {
				// do nothing..
				e.printStackTrace();
			}
		});
		deleteTwits();
	}

	@Test
	public void testDelete() throws Exception{
		deleteTwits();

	}

	private Twit saveTwit() throws TestCustomException {
		List<User> lUsers = userDAO.findAll();
		Assert.assertTrue("There are not valid users ", !lUsers.isEmpty());

		int someRandomId = (!lUsers.isEmpty())? lUsers.get(0).getIdUser():0; // if is 0, there are not valid users, so it will fail.
		Twit twit = twitService.twit(someRandomId,"This is a test");
		LOGGER.info(">>> t: {}", twit.toString());
		Assert.assertTrue("Element should contain and ID", twit.getIdTwit() > 0);
		return twit;
	}

	private void deleteTwits() {
		// try using existing one if any...
		List<Twit> list = twitService.find(0, SOME_OTHER_TEXT);
		list.forEach(t->{
			try {
				twitService.delete(t.getIdTwit());
			} catch (TestCustomException e) {
				e.printStackTrace();
			}
		});

		list = twitService.find(0, SOME_OTHER_TEXT);
		Assert.assertTrue("List should contain 0 item", list.isEmpty());
	}

}
