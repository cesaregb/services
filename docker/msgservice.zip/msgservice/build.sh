#!/bin/bash

export SEC_USER="user"
export SEC_PASSWORD="thousandeyes"

export DB_URL="jdbc:mysql://localhost:3306/msgdb"
export DB_USER="root"
export DB_PASSWORD="Welcome1"

mvn clean install package -Dmaven.test.skip=true
echo "[INFO] PACKAGE complete "
echo "[PACKAGED] Running... "
mvn jetty:run

